export interface Carro{
    marca:string,
    modelo:string,
    version:string,
    ano:number,
    descripcion:string,
    valor:number,
    image:string

}