import { Component } from '@angular/core';

@Component({
  selector: 'app-serv-finaciero',
  imports: [],
  templateUrl: './serv-finaciero.component.html',
  styleUrl: './serv-finaciero.component.css'
})
export class ServFinacieroComponent {

}
