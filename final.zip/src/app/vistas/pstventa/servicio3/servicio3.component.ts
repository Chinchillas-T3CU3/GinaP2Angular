import { Component } from '@angular/core';

@Component({
  selector: 'app-servicio3',
  imports: [],
  templateUrl: './servicio3.component.html',
  styleUrl: './servicio3.component.css'
})
export class Servicio3Component {

}
