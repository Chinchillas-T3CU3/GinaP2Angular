import { Component } from '@angular/core';

@Component({
  selector: 'app-servicio2',
  imports: [],
  templateUrl: './servicio2.component.html',
  styleUrl: './servicio2.component.css'
})
export class Servicio2Component {

}
