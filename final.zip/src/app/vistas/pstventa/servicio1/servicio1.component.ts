import { Component } from '@angular/core';

@Component({
  selector: 'app-servicio1',
  imports: [],
  templateUrl: './servicio1.component.html',
  styleUrl: './servicio1.component.css'
})
export class Servicio1Component {

}
