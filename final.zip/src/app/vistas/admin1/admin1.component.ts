import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-admin1',
  imports: [RouterModule],
  templateUrl: './admin1.component.html',
  styleUrl: './admin1.component.css'
})
export class Admin1Component {

}
