import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-p3',
  imports: [RouterModule],
  templateUrl: './p3.component.html',
  styleUrl: './p3.component.css'
})
export class P3Component {

}
