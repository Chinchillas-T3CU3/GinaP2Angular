import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-p2',
  imports: [RouterLink],
  templateUrl: './p2.component.html',
  styleUrl: './p2.component.css'
})
export class P2Component {

}
