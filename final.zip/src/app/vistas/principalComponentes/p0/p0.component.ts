import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-p0',
  imports: [RouterModule],
  templateUrl: './p0.component.html',
  styleUrl: './p0.component.css'
})
export class P0Component {

}
