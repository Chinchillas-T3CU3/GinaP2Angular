import { Component } from '@angular/core';

@Component({
  selector: 'app-p1',
  imports: [],
  templateUrl: './p1.component.html',
  styleUrl: './p1.component.css'
})
export class P1Component {

}
