import { Component } from '@angular/core';

@Component({
  selector: 'app-e3',
  imports: [],
  templateUrl: './e3.component.html',
  styleUrl: './e3.component.css'
})
export class E3Component {

}
