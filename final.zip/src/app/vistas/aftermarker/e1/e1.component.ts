import { Component } from '@angular/core';

@Component({
  selector: 'app-e1',
  imports: [],
  templateUrl: './e1.component.html',
  styleUrl: './e1.component.css'
})
export class E1Component {

}
