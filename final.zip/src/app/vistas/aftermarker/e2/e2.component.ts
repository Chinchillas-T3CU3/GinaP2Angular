import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-e2',
  imports: [RouterModule],
  templateUrl: './e2.component.html',
  styleUrl: './e2.component.css'
})
export class E2Component {

}
