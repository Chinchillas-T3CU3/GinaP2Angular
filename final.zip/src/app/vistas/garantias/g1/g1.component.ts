import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-g1',
  imports: [RouterModule],
  templateUrl: './g1.component.html',
  styleUrl: './g1.component.css'
})
export class G1Component {

}
