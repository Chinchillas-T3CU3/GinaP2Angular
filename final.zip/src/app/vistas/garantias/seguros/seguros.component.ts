import { Component } from '@angular/core';

@Component({
  selector: 'app-seguros',
  imports: [],
  templateUrl: './seguros.component.html',
  styleUrl: './seguros.component.css'
})
export class SegurosComponent {

}
