import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-g2',
  imports: [RouterModule],
  templateUrl: './g2.component.html',
  styleUrl: './g2.component.css'
})
export class G2Component {

}
