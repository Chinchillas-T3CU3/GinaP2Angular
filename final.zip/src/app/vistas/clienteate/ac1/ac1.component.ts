import { Component } from '@angular/core';

@Component({
  selector: 'app-ac1',
  imports: [],
  templateUrl: './ac1.component.html',
  styleUrl: './ac1.component.css'
})
export class Ac1Component {

}
